#include <armor.h>

inherit SHIELD;

void create()
{
	set_name("��޵P",({"typical shield","shield","typical"}) );
	set("long","�o�O���Z�}���u�éҸ˳ƪ��޵P�C\n");
	set_weight(6600);		
        if( clonep() )
                set_default_object(__FILE__);
        else {
		set("material","steel");
		set("unit", "��");
		set("value",6960);
	}
	setup();
}
