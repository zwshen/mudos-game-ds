inherit ROOM;
void create()
{
	set("short", "�\��");
        set("long", @LONG

LONG
);
	set("exits",([
	"north" : __DIR__"map_21_19",
	"east" : __DIR__"map_22_20",
	]));
        setup();
        set("map_long",1);     //show map as long
        replace_program(ROOM); //�[��L�禡xxx()�ɽЮ�������
}

