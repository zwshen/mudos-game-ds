inherit ROOM;
void create()
{
	set("short", "�\��");
        set("long", @LONG

LONG
);
	set("exits",([
	"west" : __DIR__"map_17_34",
	"north" : __DIR__"map_16_35",
	]));
        setup();
        set("map_long",1);     //show map as long
        replace_program(ROOM); //�[��L�禡xxx()�ɽЮ�������
}

